/*Animotion von icons*/

let icons_animation = document.querySelectorAll(".animat");

for(let i=0;i<icons_animation.length;i++){

    icons_animation[i].addEventListener("mouseover",function(){
        icons_animation[i].style.transform = "scale(1.1)";
    });
    
    for(let i=0;i<icons_animation.length;i++){

        icons_animation[i].addEventListener("mouseout",function(){
            icons_animation[i].style.transform = "scale(1)";
        });
    }
        
}


